<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51Nc4D7SG5TSYc9Ka8aEWMIXvy6MayAwEm5kk8WRJIxwtzG0aaA81JhL4vgSHBx8EESiojWqKsaq0LZj9tGeuExea00onmsFUOB';